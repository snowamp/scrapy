import scrapy
from scrapy import Spider
from scrapy.selector import Selector

from philosophy.items import PhilosophyItem



class PhilosophySpider(Spider):
	name = 'philosophy'
	allowed_domains = ["teachingchildrenphilosophy.org"]
	start_urls = [
	"https://www.teachingchildrenphilosophy.org/BookModule/AcrossTheBlueMountains",
	]

	def parse(self, response):
		for c in response.xpath('//h2').extract():
			yield PhilosophyItem(title=c)
		for url in response.xpath('//a/@href').extract():
			yield scrapy.Request(url, callback=self.parse)
		


